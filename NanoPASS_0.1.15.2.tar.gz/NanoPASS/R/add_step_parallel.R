# ### Within this script the processing time for the simulation shall be reduced
# ### using parallel computing (using at least half of the available CPU cores)
# ### on the system the NanoPASS application is used on.
#
# ### This script is the start of the implementation and is only meant for
# ### debugging and fixing the code so it can be used for parallel computing.
#
# ### loading the packages needed for the process
# library(doParallel)
# library(tidyverse)
# library(data.table)
#
# ### the main function that is needed to be run in parallel is the 'add_step'
# ### function of the main NanoPASS package
# add_step <- function(
#   ## this function calculates the particles moving from one position to
#   ## the next one - for every single particle individually
#   ## function variables
#   N                 ## particle number
#   , V               ## matrix with coordinates of the particle
#   , Wall_count      ## matrix with coordinates of the hits on the wall
#   , Bottom_count    ## matrix with coordinates of the hits on the bottom
#   , tau             ## time step in seconds [s]
#   , count_bottom    ## counter for bottom hits
#   , count_wall      ## counter for wall hits
#   , p_Distribution  ## scalar or matrix containing the diffusion coefficient(s)
#   , p_radius        ## radius of the well
#   , p_cell_growth_heigth ## height the cells grow at the well walls
#   , p_filling_level ## hight of the medium filling level
#   , v_s             ## particles sedimentation velocity
# ){
#   ####setting the column names####
#   pol_names <- c("phi", "rho", "z")
#   cart_names <- c("x", "y", "z")
#
#   #### function content ####
#
#   ## choosing a place long outside the cylinder
#   cart_a <- -1e+10
#   cart_b <- -1e+10
#   cart_c <- -1e+10
#
#   ## convert to cylinder coordinates
#   polar <-
#     cart2polar(
#       x = cart_a
#       , y = cart_b
#       , z = cart_c
#     )
#   pol_a <- polar[1]
#   pol_b <- polar[2]
#   pol_c <- polar[3]
#
#   ## calculation of a random distribution
#   Vcart <-
#     polar2cart(V[,1], V[,2], V[,3])
#
#   dimnames(Vcart) <- list(1:nrow(V), cart_names)
#
#   ## creation of the random motion of the particles in the cartesian coordinate
#   ## system
#   RandMotionInCart <-
#     matrix(
#       rnorm(3*N)
#       , nrow = 3
#       , byrow = T
#     )
#
#   ## calculation of the traveled distance of the given particles
#   x <- sqrt(2*p_Distribution*tau)*RandMotionInCart[1,]
#   y <- sqrt(2*p_Distribution*tau)*RandMotionInCart[2,]
#   z <- sqrt(2*p_Distribution*tau)*RandMotionInCart[3,] - v_s*tau
#
#   XYZ <-
#     matrix(
#       data = c(x,y,z)
#       , ncol = 3
#       , byrow = FALSE
#       , dimnames = list(1:length(x), cart_names)
#     )
#
#   ## particles shoud not moven when cart_a, cart_b, cart_c (outside)
#   ## if the particles are inside -> TRUE -> 1
#   ## if the particles are outside -> FALSE -> 0
#   InsideBox <-
#     !(Vcart[,1] == cart_a | Vcart[,2] == cart_b | Vcart[,3] == cart_c)
#
#   InsideBox <-
#     matrix(
#       data = c(InsideBox,InsideBox,InsideBox)
#       , ncol = 3
#       , byrow = FALSE
#     )
#
#   XYZ = XYZ * InsideBox
#
#   Vcart = Vcart + XYZ
#
#   ####convert the new cartesian coordinates to polar coordinates to check for wall and bottom hits####
#   V <-
#     t(
#       apply(Vcart, 1, cart2polar_m)
#     )
#
#   dimnames(V) <- list(1:nrow(V), pol_names)
#
#   ####checking for particles that are located outside the zylinder (those particles will be replaced back in the cylinder; particles at cart_a, cart_b and cart_c shall not be replaced! )####
#   #### find particles outside the cylinder wall ...
#   wall_indexes <-
#     {
#       V[,2] > p_radius & V[,2] < pol_b
#     }
#   #### ... and place them back inside
#   V[wall_indexes, 2] <- p_radius
#
#   ### find particles exceeding the top and bottom area of the cylinder ...
#   top_indexes <-
#     {V[,3] > p_filling_level}
#   ### ... and place them back inside
#   V[top_indexes,3] <- p_filling_level - z[top_indexes]
#
#   ### find particles that do exceed the bottom area ...
#   bottom_index <-
#     {V[,3] <= 0 & V[,3] > pol_c}
#   ### ... and raplace them
#   V[bottom_index,3] <-  0
#
#   ### now count those particles that have hit the bottom
#   bottom_hit <-V[,3] == 0
#   bottom_Start <- count_bottom + 1
#   count_bottom <- count_bottom + sum(bottom_hit)
#   bottom_End <- count_bottom
#
#   Bottom_count_i <-
#     matrix(
#       data = c(
#         V[bottom_hit,1]
#         , V[bottom_hit,2]
#       )
#       , ncol = 2
#       , byrow = FALSE
#     )
#
#   if(nrow(Bottom_count_i)>0){
#     dimnames(Bottom_count_i) <-
#       list(1:nrow(Bottom_count_i), pol_names[1:2])
#   }
#
#   Bottom_count <-
#     rbind(
#       Bottom_count
#       , Bottom_count_i
#     )
#   ### place those particles outside the controled volume
#   V[bottom_hit,1] <- pol_a
#   V[bottom_hit,2] <- pol_b
#   V[bottom_hit,3] <- pol_c
#
#   ## counting the wall hits
#   wall_hit <-
#     {
#       V[,2] == p_radius & V[,3] <= p_cell_growth_heigth & V[,3] >= 0
#     }
#   wall_start <- count_wall + 1
#   count_wall <- count_wall + sum(wall_hit)
#   wall_end <- count_wall
#
#   Wall_count_i <-
#     matrix(
#       data = c(
#         V[wall_hit, 1]
#         , V[wall_hit, 2]
#         , V[wall_hit, 3]
#       )
#       , ncol = 3
#       , byrow = FALSE
#     )
#
#   if(nrow(Wall_count_i) > 0){
#     dimnames(Wall_count_i) <-
#       list(
#         1:nrow(Wall_count_i)
#         , pol_names
#       )
#   }
#
#   Wall_count <-
#     rbind(
#       Wall_count
#       , Wall_count_i
#     )
#
#   V[wall_hit, 1] <- pol_a
#   V[wall_hit, 2] <- pol_b
#   V[wall_hit, 3] <- pol_c
#
#   ####setting the dimension names for the matrices####
#   dimnames(V) <- list(c(1:nrow(V)), pol_names)
#   dimnames(Vcart) <- list(c(1:nrow(Vcart)), cart_names)
#   if(nrow(Bottom_count) > 0){
#     dimnames(Bottom_count) <-
#       list(
#         c(
#           1:nrow(Bottom_count)
#         )
#         , pol_names[1:2]
#       )
#   }
#   if(nrow(Wall_count) > 0){
#     dimnames(Wall_count) <-
#       list(
#         c(
#           1:nrow(Wall_count)
#         )
#         , pol_names
#       )
#   }
#
#   ####return the generated values####
#   return(
#     list(
#       "V" = V %>% as.data.frame()
#       , "Vcart" = Vcart %>% as.data.frame()
#       , "Wall_count" = Wall_count %>% as.data.frame()
#       , "Bottom_count" = Bottom_count %>% as.data.frame()
#       , "count_bottom" = count_bottom
#       , "count_wall" = count_wall
#     )
#   )
# }
#
# ### for debugging - the add step function
# distribution_processing <-
#   function(
#     uip_N = ~p_N
#   ){
#     ## read in the sample distribution
#     Sample_Distribution <-
#       NanoPASS::example_distribution %>%
#       data.table::data.table()
#
#     ## Clean the input data, because there are only two columns
#     ## allowed: "Diffusion.Coefficient" "example.distribution"
#     ## The first one needs to be the "Diffusion Coefficient",
#     ## the second one has to be the "Distribution".
#     ## The names of the columns are not strict but the order _is_!!!
#
#     if(ncol(Sample_Distribution) > 2){
#       crayon::bgRed("Check the input style of your distribution CSV file!\nThere are more than two columns ...") %>%
#         crayon::white() %>%
#         cat("\n")
#       stop("
# There is an issue with the provided distribution data csv ...\n
# Maybe you exported row names while writing the csv file.\n
# Those might be misinterpreted as a third column ... ?!")
#     }
#
#
#     ## load diffusion coefficient/particles size
#     D_value_from_table <-
#       Sample_Distribution %>%
#       .[,1]
#
#     ## read in the values for the cumulative distribution
#     ## load the values for cummulative distribution
#     D_cumsum_from_table <-
#       Sample_Distribution %>%
#       .[,2]
#
#     ## find the values that are larger than 0 in the cumulative
#     ## distribution getting the non-zero elements from the
#     ## distribution
#     D_cumsum <-
#       Sample_Distribution[
#         Sample_Distribution[[2]] > 0
#         ][,2]
#
#     ## getting the non-zero elements diffusion coefficents from
#     ## the list
#     D_value <-
#       Sample_Distribution[
#         Sample_Distribution[[2]] > 0
#         ][,1]
#
#     ## multiply the cumulative coefficient with the number of
#     ## given particles
#     D_cumsum_N <-
#       round(
#         D_cumsum * uip_N
#       )
#
#     ## loop over the elements
#     Distribution <- c()
#     for(ELEMENT in seq_along(D_cumsum_N[[1]])){
#       if(ELEMENT == 1){
#         Distribution[D_cumsum_N[[1]][ELEMENT]] <-
#           D_value[[1]][ELEMENT]
#       }
#       if(ELEMENT == length(D_cumsum_N[[1]])){
#         Distribution[{D_cumsum_N[[1]][ELEMENT-1]+1}:uip_N] <-
#           D_value[[1]][D_cumsum_N == uip_N][1]
#         if(D_cumsum_N[[1]][ELEMENT-1] == uip_N){
#           break
#         }
#       }
#       if(ELEMENT>1 && ELEMENT < length(D_cumsum_N[[1]])){
#         Distribution[{D_cumsum_N[[1]][ELEMENT-1]}:D_cumsum_N[[1]][ELEMENT]+1] <-
#           D_value[[1]][ELEMENT]
#       }
#     }
#
#     ## return the generated distribution based on the given
#     ## input
#     return(Distribution[1:uip_N])
#   }
#
# p_Distribution <-           ## generation of the diffusion coefficient matrix
#   distribution_processing(
#     uip_N = p_N
#   )
#
# # defining the parameters needed for debugging ----------------------------
#
#
# # number of particles -----------------------------------------------------
#
# N <- p_N <- 1000
# uip_bottom_area <- 0.34
# uip_filling_level <- 0.88
#
# # create a random matrix with the number of particles  --------------------
# p_alpha <- 2*pi
# p_area <- uip_bottom_area*1e+14
# p_filling_level <- uip_filling_level * 1e+7
# p_radius <- sqrt(p_area/pi)
#
# V <- matrix(
#   data = c(
#     p_alpha * runif(p_N) ## angle rho
#     , sqrt(runif(p_N)) * p_radius ## euclidian distance phi
#     , p_filling_level * runif(p_N)) ## z
#   , ncol = 3 ## matrix with 3 columns (rho, phi, z)
#   , byrow = FALSE ## filled columnwise
# )
#
# uip_effective_density <- 1.552
# uip_temperature <- 37
# uip_medium_density <- 1.0037
# uip_medium_viscosity <- 0.725
# uip_accelleration <- 9.80665
# uip_temperature_NTA <- 24.8
# uip_medium_viscosity_NTA <- 0.893
# uip_cell_growth_height <- 0.54
#
# p_cell_growth_heigth <- uip_cell_growth_height * 1e+7
#
# p_cell_size <- 18.1e+3              ## cell size [nm] (used for time step adjustment)
# p_density <- uip_effective_density * 1e-24
# ## effective density [kg nm-3]
# p_temperature <- 273.15 + uip_temperature
# ## incubation temperature [K]
# p_k_Boltzmann <- 1.380568e-5        ## Boltzmann constant [kg nm2 s-2 K]
# p_medium_density <- uip_medium_density * 1e-24
# ## media density [kg nm-3]
# p_accelleration <- uip_accelleration * 1e+9       ## acceleration of gravity [nm s-2]
# p_medium_viscosity <- uip_medium_viscosity * 1e-12
#
#
# p_temperature_NTA <- 273.15 + uip_temperature_NTA
# ## temperature during the NTA measurement [K]
# p_medium_viscosity_NTA <- uip_medium_viscosity_NTA * 1e-12
#
# ## calculating the radius of the hydration hull
# hydr_radius <-
#   {p_k_Boltzmann*p_temperature_NTA}/{6*pi*p_medium_viscosity_NTA*p_Distribution} ##
# ## calculating the effective mass of the particles [kg]
# ## an effective mass larger than 0 leads to particle segmentation
# p_effective_mass <-
#   {4*pi*hydr_radius^3}*(p_density - p_medium_density)/{3}
# ## calculating the sedimentation velocity [nm/s]
# v_s <-
#   {p_effective_mass*p_accelleration*p_Distribution}/{p_k_Boltzmann*p_temperature}
# ## calculation of the particle diameter
# particle_diameter <-
#   mean(hydr_radius*2)
#
# ## calculating the sedimentation velocity [nm/s]
# v_s <-
#   {p_effective_mass*p_accelleration*p_Distribution}/{p_k_Boltzmann*p_temperature}
#
#
# # setting the simulation time ---------------------------------------------
# uip_simulation_time <- 1
# simulation_time <- uip_simulation_time*3600 ## in seconds [s]
# tau <- 1  ## time step in [s]
#
# ####initial counter for wall and bottom hits####
# count_wall <- 0
# count_bottom <- 0
#
# ####setting the column names####
# pol_names <- c("phi", "rho", "z")
# cart_names <- c("x", "y", "z")
#
# ####initial matrix for polar coordinates of wall hits####
# Wall_count <-
#   matrix(
#     ncol = 3
#     , dimnames = list(NA,pol_names)
#   )[-1,]
#
# ####initial matrix for polar coordinates of bottom hits####
# Bottom_count <-
#   matrix(
#     ncol = 2
#     , dimnames = list(NA,pol_names[1:2])
#   )[-1,]
#
# Input <-
#   list(
#     "V" = V
#     , "Wall_count" = Wall_count
#     , "Bottom_count" = Bottom_count
#     , "count_bottom" = count_bottom
#     , "count_wall" = count_wall
#   )
#
# uip_snap_shot <- 1
# times <-
#   seq(
#     from = {3600*uip_snap_shot}
#     , to = (uip_simulation_time*3600)
#     , by = {3600*uip_snap_shot}
#   )
# df <- data.frame()
# window <- 100
#
# Output <- list()
#
# # the actual simulation over time starts here -----------------------------
#
# init <- 1
# # for(i in seq(simulation_time)){
#   for(i in seq(10)){
#   Input <-
#     add_step(
#       N = p_N
#       , V = Input$V
#       , Wall_count = Input$Wall_count
#       , Bottom_count = Input$Bottom_count
#       , tau = tau
#       , count_bottom = Input$count_bottom
#       , count_wall = Input$count_wall
#       , p_Distribution = p_Distribution
#       , p_radius = p_radius
#       , p_cell_growth_heigth = p_cell_growth_heigth
#       , p_filling_level = p_filling_level
#       , v_s = v_s
#     )
#
# }## end of the sequential 'for'-loop
#
