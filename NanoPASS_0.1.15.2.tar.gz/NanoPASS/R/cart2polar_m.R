#' Convert a cartesian polar system into a polar.
#'
#'@description This function uses a matrix as input with the first column to be
#'  the \emph{x} coordinate, the second one to be the \emph{y} coordinate and
#'  the third one to be the \emph{z} coordinate.
#'  The output will be a matrix with coordinates that describe positions in
#'  3D-space using polar coordinate system with:
#'  \describe{
#'    \item{phi (\eqn{\phi})}{in the first column}
#'    \item{rho (\eqn{\rho})}{in the second column}
#'    \item{z}{in the third column}
#'  }
#'
#'@param m matrix like object with the first column beeing \emph{x}, second
#'  column beeing \emph{y} and third column beeing \emph{z} coordinate of a
#'  cartesian coordinate system
#'
#'@examples m <- matrix(data = rnorm(30), ncol = 3)
#' m_cart <- polar2cart_m(m = m)
#' cart2polar_m(m = m_cart)

#'@export
cart2polar_m <- function(m){
  rho <- sqrt(m[1]**2+m[2]**2)

  ## calculation of the angle phi
  if(m[1] == 0 && m[2] == 0){
    phi <- 0
  }
  if(m[1] >= 0){
    phi <- asin(m[2]/{sqrt(m[1]**2+m[2]**2)})
  }
  if(m[1] > 0){
    phi <- atan(m[2]/m[1])
  }
  if(m[1] < 0){
    phi <- -(asin(m[2]/{sqrt(m[1]**2+m[2]**2)})+pi)
  }
  z <- m[3]
  return(c(phi, rho, z))
}

#'@family \code{\link{polar2cart_m}}
