#' Converting polar coordinates into cartesian coordinates.
#'
#' This function converts the coordinate system from a polar one to a cartesian.
#' It uses a matrix with three columns as an input whereas the first row is seen
#'  as the \eqn{\phi}, the second as the \eqn{\rho} and the third one as the \emph{z} coordinate.
#'
#' @param m Matrix with the dimension of dim(3,n)
#' @usage
#' polar2cart_m(m)
#' @examples
#' m <- matrix(data = rnorm(30), ncol = 3)
#' polar2cart_m(m = m)
#' @export
polar2cart_m <- function(m){
    x <-
        m[,2]*cos(m[,1])
    y <-
        m[,2]*sin(m[,1])
    z <- tryCatch(m[,3], error = function(x) return(rep(0, times = {m %>% nrow()})))
    return(
        matrix(data = c(x,y,z), ncol = 3)
    )
}
