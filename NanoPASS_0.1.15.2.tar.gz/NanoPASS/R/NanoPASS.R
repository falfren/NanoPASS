#' NanoPASS package
#'
#' Shiny App that simulates the sedimentation behaviour of nano particles in
#' defined solutions.
#' This Simulator is a main step in issues tackling dosimetrics.
#'
#' @docType package
#' @name NanoPASS
#' @importFrom magrittr "%>%"
#' @importFrom stats rnorm runif setNames
#' @importFrom data.table data.table :=
#' @importFrom utils citation installed.packages install.packages
#'
NULL

##
if(getRversion() >= "2.15.1") utils::globalVariables(c("."))
