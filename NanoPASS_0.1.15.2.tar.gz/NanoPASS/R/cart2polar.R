#' Convert cartesian coordinates into a polar coordinates.
#'
#'@description This function uses a number vector as input with the first number
#'  to be the \emph{x} coordinate, the second one to be the \emph{y} coordinate
#'  and the third one to be the \emph{z} coordinate.
#'  The output will be a number vector with coordinates that describe positions
#'  in 3D-space using polar coordinate system with:
#'  \describe{
#'    \item{phi (\eqn{\phi})}{in the first position}
#'    \item{rho (\eqn{\rho})}{in the second position}
#'    \item{z}{in the third position}
#'  }
#'
#'@param x beeing \emph{x}-coordinate
#'@param y beeing \emph{y}-coordinate
#'@param z beeing \emph{z}-coordinate
#'
#'
#'@examples m <- matrix(data = rnorm(30), ncol = 3)
#' m_cart <- polar2cart_m(m = m)
#' cart2polar(x = m_cart[1,1], y = m_cart[1,2], z = m_cart[1,3])

#'@export
cart2polar <- function(x, y, z){
  rho <- sqrt(x**2+y**2)

  ## calculation of the angle phi
  if(x == 0 && y == 0){
    phi <- 0
  }
  if(x >= 0){
    phi <- asin(y/{sqrt(x**2+y**2)})
  }
  if(x > 0){
    phi <- atan(y/x)
  }
  if(x < 0){
    phi <- -(asin(y/{sqrt(x**2+y**2)})+pi)
  }
  z <- z
  return(c(phi, rho, z))
}

#'@family \code{\link{polar2cart_m}}
