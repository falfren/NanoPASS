#' Example Distribution
#'
#' @description
#' This is an example distribution file which was used
#' at the BfR.
#'
#' @docType data
#'
#' @usage data(example_distribution)
#'
#' @examples
#' library(magrittr)
#' library(readr)
#' NanoPASS::example_distribution %>%
#' readr::write_csv(
#'   path = paste(getwd(),
#'   "example_distribution.csv",
#'   sep = "/")
#'   )
#'  message(paste("File written to: ", getwd(),
#'    "example_distribution.csv",
#'    sep = "/"))
#'
#' @format A table like data format with columns 'Diffusion Coefficient' and 'example distribution'.
#' \describe{
#'   \item{Diffusion.Coefficient}{}
#'   \item{example.distribution}{}
#' }
#'
#' @keywords datasets
#'
"example_distribution"
