#' Converting polar coordinates into cartesian coordinates.
#'
#' Despite the function \code{\link{polar2cart_m}} this function is build to
#' convert only a single set of \eqn{\phi}, \eqn{\rho} and \emph{z}.
#'
#'@param phi phi angle (\eqn{\phi}) in a polar coordinate system
#'@param rho rho angle (\eqn{\rho}) in a polar coordinate system
#'@param z z-coordinate in a polar coordinate system
#'
#'@examples
#'m <- matrix(data = rnorm(3), ncol = 3)
#'polar2cart(
#'  phi = m[,1],
#'  rho = m[,2],
#'  z = m[,3]
#'  )
#'
#'@export
polar2cart <- function(phi, rho, z){
  x <- rho*cos(phi)
  y <- rho*sin(phi)
  z <- z
  return(
    matrix(data = c(x,y,z), ncol = 3)
  )
}
